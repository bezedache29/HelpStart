Compte student DEV2 Délégué
login => bezedache29@gmail.com
pwd => azertyuiop

Compte student DEV1
login => anto-lopez@gmail.com
pwd => azerty12345

compte student en attente de modification de profil
login => jean-mich@muche.fr
pwd => azerty12345

Compte prof1
login => simon-strueux@best.fr
pwd => azerty12345

Compte prof2
login => kellydiote@oops.fr
pwd => azerty12345

Compte admin
login => jo.lemodo@gmail.com
pwd => password