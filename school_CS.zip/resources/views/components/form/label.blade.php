@props(['field', 'label'])

<label for="{{ $field }}" class="form-label">{{ $label }}</label>