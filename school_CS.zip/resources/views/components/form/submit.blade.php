@props(['label' => 'Enregistrer', 'type' => 'primary'])

<button type="submit" class="btn btn-{{ $type }} mt-3">{{ $label }}</button>