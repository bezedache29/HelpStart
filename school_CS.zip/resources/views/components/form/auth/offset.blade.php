@props(['css' => 'col-md-6'])

<div class="{{ $css }} offset-md-4">

    {{ $slot }}

</div>