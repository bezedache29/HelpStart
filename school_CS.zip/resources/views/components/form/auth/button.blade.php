@props(['label' => 'S\'enregistrer', 'type' => 'primary'])

<button type="submit" class="btn btn-{{ $type }}">{{ $label }}</button>



