@props(['field', 'label'])

<label for="{{ $field }}" class="col-md-4 col-form-label text-md-right">{{ $label }}</label>