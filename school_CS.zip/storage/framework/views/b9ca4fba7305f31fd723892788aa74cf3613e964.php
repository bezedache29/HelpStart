<?php $attributes = $attributes->exceptProps(['label']); ?>
<?php foreach (array_filter((['label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__($label)); ?></div>

                <div class="card-body">

                    <?php echo e($slot); ?>


                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/components/form/auth/container.blade.php ENDPATH**/ ?>