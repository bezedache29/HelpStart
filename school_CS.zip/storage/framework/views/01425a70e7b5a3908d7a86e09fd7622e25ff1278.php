<?php $attributes = $attributes->exceptProps(['label', 'field', 'value' => null, 'type' => 'text']); ?>
<?php foreach (array_filter((['label', 'field', 'value' => null, 'type' => 'text']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="mb-3">
    <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>" class="form-control" id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" value="<?php echo e(old($field) ?? $value); ?>">
    
    <p class="text-danger"><?php echo e($errors->first($field)); ?></p>
</div><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/components/form/input.blade.php ENDPATH**/ ?>