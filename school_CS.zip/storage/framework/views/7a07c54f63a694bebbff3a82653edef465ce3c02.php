<?php $attributes = $attributes->exceptProps(['route', 'routeId' => null, 'method' => 'post', 'files' => false]); ?>
<?php foreach (array_filter((['route', 'routeId' => null, 'method' => 'post', 'files' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<form action="<?php echo e(route($route, $routeId)); ?>" method="<?php echo e($method); ?>" <?php if($files): ?> enctype='multipart/form-data' <?php endif; ?>>
    <?php echo csrf_field(); ?>

   <?php echo e($slot); ?>


</form><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/components/form.blade.php ENDPATH**/ ?>