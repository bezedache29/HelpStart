<?php $attributes = $attributes->exceptProps(['field', 'label']); ?>
<?php foreach (array_filter((['field', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="custom-file mb-3">
    <input type="file" name="<?php echo e($field); ?>[]" class="custom-file-input" id="customFile" multiple>
    <label class="custom-file-label" for="customFile"><?php echo e($label); ?></label>
</div><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/components/form/files.blade.php ENDPATH**/ ?>