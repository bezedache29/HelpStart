

<?php $attributes = $attributes->exceptProps(['label', 'field', 'value', 'checked', 'id' => $field]); ?>
<?php foreach (array_filter((['label', 'field', 'value', 'checked', 'id' => $field]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div class="form-check">
    <input class="form-check-input" type="checkbox" value="<?php echo e($value); ?>" id="<?php echo e($id); ?>" name="<?php echo e($field); ?>" <?php if($checked): ?> checked <?php endif; ?>>
    <label class="form-check-label" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

    </label>
</div>


<?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/components/form/checkbox.blade.php ENDPATH**/ ?>