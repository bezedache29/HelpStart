

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <a href="<?php echo e(route('help.create')); ?>" class="btn btn-primary">Nouvelle demande</a>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <table class="table table-bordered">
            <?php $__currentLoopData = $help_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($help_request->title); ?></td>
                    <td><?php echo e($help_request->student->user->name); ?></td>
                    <td><?php echo e($help_request->visibility_name); ?></td>
                    <td><?php echo e($help_request->student->promotion->full_name); ?></td>
                    <td><a href="<?php echo e(route('help.show', $help_request->id)); ?>">Voir</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
        <div class="d-flex justify-content-center">
            <?php echo e($help_requests->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/help/index.blade.php ENDPATH**/ ?>