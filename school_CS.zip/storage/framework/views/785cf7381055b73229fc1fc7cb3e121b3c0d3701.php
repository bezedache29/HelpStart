

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <h1 class="mb-5 mt-2 text-center">Liste des leçons de <?php echo e($course->name); ?> pour <?php echo e($course->promotion->name); ?></h1>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lesson-create')): ?>
                <a href="<?php echo e(route('course.lesson.create', $course->id)); ?>" class="btn btn-primary">Ajouter une leçon</a>
            <?php endif; ?>

            <table class="table mt-5 w-100">
                <thead>
                    <tr>
                        <th scope="col" style="width: 10%">Ordre</th>
                        <th scope="col" style="width: 40%">Nom de la leçon</th>
                        <th scope="col" style="width: 15%" class="text-center">Option</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 10%"><?php echo e($lesson->order); ?></td>
                            <td style="width: 40%"><?php echo e($lesson->title); ?></td>
                            <td style="width: 15%" class="text-center"><a href="<?php echo e(route('course.lesson.show', [$course->id, $lesson->id])); ?>" class="btn btn-primary">Voir la leçon</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/course/show.blade.php ENDPATH**/ ?>