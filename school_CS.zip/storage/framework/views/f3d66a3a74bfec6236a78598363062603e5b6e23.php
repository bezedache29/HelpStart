

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <?php switch(true):
                    case ($user->isStudent() && $user->profile->promotion != null): ?>
                        <div class="card" style="width: 18rem;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($user->name); ?> <?php echo e($user->firstname); ?></h5>
                                <br>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo e($user->email); ?></h6>
                                <br>
                                <p class="card-text"><?php echo e($user->profile->promotion->name); ?> <?php echo e($user->profile->promotion->section->name); ?></p>
                                <br>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('moderation.approve', $user->id)); ?>" class="btn btn-success mr-1">Valider la modification</a>
                                    <a href="<?php echo e(route('moderation.deny', $user->id)); ?>" class="btn btn-danger ml-1">Refuser la modification</a>
                                </div>
                            </div>
                        </div>
                    <?php break; ?>;

                <?php endswitch; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Pas de profil à modérer</p>
            <?php endif; ?>
            
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/moderation/index.blade.php ENDPATH**/ ?>