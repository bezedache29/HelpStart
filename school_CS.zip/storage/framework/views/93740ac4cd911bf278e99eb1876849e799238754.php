

<?php $__env->startSection('content'); ?>
    <div class="container">

        
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <h1 class="mb-5 mt-2 text-center">Liste de mes cours</h1>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course-create')): ?>
                <a href="<?php echo e(route('course.create')); ?>" class="btn btn-primary">Ajouter un cours</a>
            <?php endif; ?>

            <table class="table mt-5 w-100">
                <thead>
                    <tr>
                        <th scope="col" style="width: 20%">Nom du cours</th>
                        <th scope="col" style="width: 20%">Promotion</th>
                        <th scope="col" style="width: 20%">Intervenant</th>
                        <th scope="col" style="width: 15%">Option</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 20%"><?php echo e($course->name); ?></td>
                            <td style="width: 20%"><?php echo e($course->promotion->name); ?></td>
                            <td style="width: 20%"><?php echo e($course->teacher->user->full_name); ?></td>
                            <td style="width: 15%"><a href="<?php echo e(route('course.show', $course->id)); ?>" class="btn btn-primary">Voir les leçons</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\01-BACK\DEV2\school\resources\views/course/index.blade.php ENDPATH**/ ?>